<aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="dashboard.php" style="font-weight: bold; font-size: 20px;"><i class="menu-icon fa fa-laptop"></i>Dashboard </a>
                    </li>
                   
                   
                    <li class="menu-item-has-children dropdown">
                        <a href="#" style="font-weight: bold; font-size: 20px;" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-table"></i>Product</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-plus"></i><a href="add-product.php" style="font-weight: bold; font-size: 20px;">Add Product</a></li>
                            <li><i class="fa fa-list"></i><a href="manage-product.php" style="font-weight: bold; font-size: 20px;">View Product</a></li>
                        </ul>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <a href="#" style="font-weight: bold; font-size: 20px;" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-truck"></i>Supplier</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-plus" aria-hidden="true"></i><a href="add-supplier.php" style="font-weight: bold; font-size: 20px;">Add Supplier</a></li>
                            <li><i class="fa fa-list" aria-hidden="true"></i><a href="manage-supplier.php" style="font-weight: bold; font-size: 20px;">View Supplier</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="log.php" style="font-weight: bold; font-size: 20px;"><i class="menu-icon fa fa-plus-square-o" aria-hidden="true"></i>Stock In </a>
                    </li>
                    <li>
                        <a href="sales.php" style="font-weight: bold; font-size: 20px;"><i class="menu-icon fa fa-credit-card"></i>Sales Entry </a>
                    </li>
                    <li>
                        <a href="log_data.php" style="font-weight: bold; font-size: 20px;"><i class="menu-icon fa fa-history"></i>Log History</a>
                    </li>
                    <li>
                        <a href="usermanual.php" style="font-weight: bold; font-size: 20px;"><i class="menu-icon fa fa-info-circle"></i>User Manual</a>
                    </li>

                </ul>
            </div><!-- /.navbar-collapse --> 
        </nav>
    </aside>
