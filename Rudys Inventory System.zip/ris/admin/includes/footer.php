  <footer class="site-footer">
            <div class="footer-inner bg-white">
                <div class="row">
                    
                    <div class="col-sm-6 text-center">
                    Rudys Inventory System by Aiman Matin
                    </div>
                </div>
            </div>
        </footer>