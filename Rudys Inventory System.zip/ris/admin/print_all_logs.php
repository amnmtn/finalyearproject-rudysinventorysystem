<?php
session_start();
include('includes/dbconnection.php');


if (strlen($_SESSION['vpmsaid']) == 0) {
    header('location:logout.php');
    exit();
}

// Fetch all log data
$sql = "SELECT * FROM log ORDER BY LogDate DESC, LogTime DESC";
$result = mysqli_query($con, $sql);
?>

<!doctype html>
<html lang="en">
<head>
    <title>RIS - Print All Log Data</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <style>
        @media print {
            .btn {
                display: none; /* Hide the print button in print view */
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center my-4">Log Data</h1>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>In/Out</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Supplier Name</th>
                    <th>Product Name</th>
                    <th>Quantity</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $counter = 1;
                while ($row = mysqli_fetch_assoc($result)) {
                    $inOutButtonText = ($row['Type'] == 0) ? 'Out' : 'Entered';
                    $quantitySign = ($row['Type'] == 0) ? '-' . $row['Quantity'] : '+' . $row['Quantity'];
                ?>
                    <tr>
                        <td><?php echo $counter++; ?></td>
                        <td><?php echo $inOutButtonText; ?></td>
                        <td><?php echo $row['LogDate']; ?></td>
                        <td><?php echo $row['LogTime']; ?></td>
                        <td><?php echo $row['SupplierName'] == '-' ? 'N/A' : $row['SupplierName']; ?></td>
                        <td><?php echo $row['ProductName']; ?></td>
                        <td><?php echo $quantitySign; ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        <div class="text-center mt-4">
            <button onclick="window.print();" class="btn btn-primary">Print</button>
            <!-- Back button with JavaScript redirection to log_data.php -->
            <button onclick="window.location.href='log_data.php';" class="btn btn-primary">Back</button>
        </div>
    </div>
</body>
</html>
