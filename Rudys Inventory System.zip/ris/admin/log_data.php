<?php
session_start();
include('includes/dbconnection.php');

if (strlen($_SESSION['vpmsaid']) == 0) {
    header('location:logout.php');
    exit();
}

// Pagination logic (for screen view)
$limit = 10; // Number of records per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $limit;

// Fetch paginated log data
$sql = "SELECT * FROM log ORDER BY LogDate DESC, LogTime DESC LIMIT $start, $limit";
$result = mysqli_query($con, $sql);

// Get the total number of records for pagination
$totalResult = mysqli_query($con, "SELECT COUNT(*) AS total FROM log");
$totalRows = mysqli_fetch_assoc($totalResult)['total'];
$totalPages = ceil($totalRows / $limit);


?>

<!doctype html>
<html lang="en">
<head>
    <title>Log History</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

    <style>
    /* Hide everything except the table and the print button */
    .print-only {
        display: none; /* Hide by default */
    }
    
    @media print {
        body * {
            visibility: hidden;
        }
        .content, .content * {
            visibility: visible;
        }
        .content {
            position: absolute;
            top: 0;
            left: 0;
        }
        .pagination, .breadcrumbs, .header, .sidebar, .footer {
            display: none;
        }

        /* Hide the buttons in the In/Out column but keep the text */
        .table .btn {
            display: none;
        }

        /* Ensure the 'In' or 'Out' text remains visible */
        .table td {
            visibility: visible;
        }

        .table .print-only {
            display: inline; /* Show the text (In/Out) in the print view */
        }

        /* Prevent page breaks between table rows */
        .table {
            page-break-inside: auto;
        }
        .table tr {
            page-break-inside: avoid;
            page-break-after: auto;
        }
        .pagination {
            display: none; /* Hide pagination in the print view */
        }
        
    }
    
</style>
</head>
<body>
    <?php include_once('includes/sidebar.php'); ?>
    <?php include_once('includes/header.php'); ?>

    <div class="breadcrumbs">
        <div class="breadcrumbs-inner">
            <div class="row m-0">
                <div class="col-sm-4">
                    <div class="page-header float-left">
                        <div class="page-title">
                            <h1>Log Data</h1>
                        </div>
                    </div>
                </div>
                <div class="col-sm-8">
                    <div class="page-header float-right">
                        <div class="page-title">
                            <ol class="breadcrumb text-right">
                                <li><a href="dashboard.php">Dashboard</a></li>
                                <li class="active">Log Data</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="content">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Log Data</strong>
                        </div>
                        <div class="card-body">
                            <!-- Print All Logs Button -->
                            <div class="text-right mb-3">
                                <button type="button" class="btn btn-danger" onclick="deleteAllLogs()">
                                    <i class="fa fa-trash"></i> Delete All Logs
                                </button>
                                <a href="print_all_logs.php" class="btn btn-info"><i class="fa fa-print"></i> Print All Logs</a>
                            </div>
                            <!-- Log Data Table with Pagination -->
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>In/Out</th>
                                        <th>Date</th>
                                        <th>Time</th>
                                        <th>Supplier Name</th>
                                        <th>Product Name</th>
                                        <th>Quantity</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $counter = $start + 1;
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        $inOutButtonClass = ($row['Type'] == 0) ? 'btn-danger' : 'btn-success';
                                        $inOutButtonText = ($row['Type'] == 0) ? 'Out' : 'Entered';
                                        $quantitySign = ($row['Type'] == 0) ? '-' . $row['Quantity'] : '+' . $row['Quantity'];
                                    ?>
                                        <tr>
                                            <td><?php echo $counter++; ?></td>
                                            <td>
                                                <button class="btn <?php echo $inOutButtonClass; ?>" disabled>
                                                    <?php echo $inOutButtonText; ?>
                                                </button>
                                                <!-- In the print view, show only the text without the button -->
                                                <span class="print-only">
                                                    <?php echo $inOutButtonText; ?>
                                                </span>
                                            </td>
                                            <td><?php echo $row['LogDate']; ?></td>
                                            <td><?php echo $row['LogTime']; ?></td>
                                            <td><?php echo $row['SupplierName'] == '-' ? 'N/A' : $row['SupplierName']; ?></td>
                                            <td><?php echo $row['ProductName']; ?></td>
                                            <td><?php echo $quantitySign; ?></td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>

                            <!-- Pagination Links -->
                            <nav aria-label="Page navigation">
                                <ul class="pagination justify-content-center">
                                    <li class="page-item <?php if ($page == 1) echo 'disabled'; ?>">
                                        <a class="page-link" href="?page=1">&laquo;&laquo;</a>
                                    </li>
                                    <li class="page-item <?php if ($page == 1) echo 'disabled'; ?>">
                                        <a class="page-link" href="?page=<?php echo $page - 1; ?>">&laquo;</a>
                                    </li>
                                    <?php for ($i = 1; $i <= $totalPages; $i++) { ?>
                                        <li class="page-item <?php if ($i == $page) echo 'active'; ?>">
                                            <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                                        </li>
                                    <?php } ?>
                                    <li class="page-item <?php if ($page == $totalPages) echo 'disabled'; ?>">
                                        <a class="page-link" href="?page=<?php echo $page + 1; ?>">&raquo;</a>
                                    </li>
                                    <li class="page-item <?php if ($page == $totalPages) echo 'disabled'; ?>">
                                        <a class="page-link" href="?page=<?php echo $totalPages; ?>">&raquo;&raquo;</a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>


    <?php include_once('includes/footer.php'); ?>
    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
<script>
function deleteAllLogs() {
    if (confirm("Are you sure you want to delete all log entries?")) {
        // Create an AJAX request to delete_all_logs.php
        const xhr = new XMLHttpRequest();
        xhr.open("POST", "delete_all_logs.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                // Reload the page or handle the response if needed
                alert("All log entries have been deleted successfully.");
                window.location.reload(); // Refresh the page to show updated data
            }
        };
        
        xhr.send("delete=all"); // Send a parameter to identify the delete request
    }
}
</script>

<style>
body {
  display: table;
  font-family: "Open Sans", sans-serif;
  font-size: 16px;
  width: 100%; 
  background-color: #f1f2f7;
}
</style>


</body>
</html>
