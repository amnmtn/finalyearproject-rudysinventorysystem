<?php
session_start();
include('includes/dbconnection.php');

if (strlen($_SESSION['vpmsaid']) == 0) {
    header('location:logout.php');
    exit();
}

// Check if the request is a POST request and contains the expected parameter
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete']) && $_POST['delete'] === 'all') {
    // Execute delete query
    $sql = "DELETE FROM log";
    if (mysqli_query($con, $sql)) {
        echo "success"; // Return success response for AJAX to handle
    } else {
        echo "error"; // Return error if deletion fails
    }
}
?>
