<?php
session_start();
include('includes/dbconnection.php');

if (strlen($_SESSION['vpmsaid']) == 0) {
    header('location:logout.php');
}


// Set timezone to Malaysia (UTC+8)
date_default_timezone_set('Asia/Kuala_Lumpur');

// Current Date and Time for UTC+8
$currentDate = date('Y-m-d');
$currentTime = date('H:i:s');

// Retrieve Supplier and Product data
$supplierQuery = mysqli_query($con, "SELECT SupplierName FROM supplier");
$productQuery = mysqli_query($con, "SELECT ProductName FROM product");

if (isset($_POST['submit'])) {
    $logDate = $currentDate;
    $logTime = $currentTime;
    $supplierName = $_POST['supplierName'];
    $productName = $_POST['productName'];
    $quantity = $_POST['quantity'];
    $notes = $_POST['notes'];
    $adminID = $_SESSION['vpmsaid'];
    $logType = 1; // Set Type to 1 indicating that stock has entered

    // Insert log data with Type set to 1
    $insertLog = mysqli_query($con, "INSERT INTO log (LogDate, LogTime, SupplierName, ProductName, Quantity, Notes, AdminID, Type) 
                                     VALUES ('$logDate', '$logTime', '$supplierName', '$productName', '$quantity', '$notes', '$adminID', '$logType')");

    if ($insertLog) {
        // Update Product Quantity
        $updateQuantity = mysqli_query($con, "UPDATE product SET Quantity = Quantity + $quantity WHERE ProductName = '$productName'");
        if ($updateQuantity) {
            echo "<script>alert('Log entry added and product quantity updated successfully.');</script>";
        } else {
            echo "<script>alert('Error updating product quantity.');</script>";
        }
    } else {
        echo "<script>alert('Error adding log entry.');</script>";
    }
}
?>

<!doctype html>
<html lang="en">


<head>
    <title>Stock Entry</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

<style>
body {
  display: table;
  font-family: "Open Sans", sans-serif;
  font-size: 16px;
  width: 100%; 
  background-color: #f1f2f7;
}
</style>
</head>
<body>
    <?php include_once('includes/sidebar.php'); ?>
    <?php include_once('includes/header.php'); ?>

    <div class="breadcrumbs">
        <div class="breadcrumbs-inner">
            <div class="row m-0">
                <div class="col-sm-4">
                    <div class="page-header float-left">
                        <div class="page-title">
                            <h1>Stock In</h1>
                        </div>
                    </div>
                </div>
                <div class="col-sm-8">
                    <div class="page-header float-right">
                        <div class="page-title">
                            <ol class="breadcrumb text-right">
                                <li><a href="dashboard.php">Dashboard</a></li>
                                <li class="active">Stock In</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
   
   
 <br>
    <div class="content">
        <div class="animated fadeIn">
            <div class="card">
                <div class="card-header">
                    <strong class="card-title">Add Log Entry (Stock In)</strong>
                </div>
                <div class="card-body">
                    <form method="post">
                        <!-- Date and Time -->
                        <div class="form-group">
                            <label for="date">Date</label>
                            <input type="text" id="date" name="date" class="form-control" value="<?php echo $currentDate; ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label for="time">Time</label>
                            <input type="text" id="time" name="time" class="form-control" value="<?php echo $currentTime; ?>" readonly>
                        </div>

                        <!-- Supplier Name -->
                        <div class="form-group">
                            <label for="supplierName">Supplier Name</label>
                            <select id="supplierName" name="supplierName" class="form-control" required>
                                <?php while($row = mysqli_fetch_array($supplierQuery)) { ?>
                                    <option value="<?php echo $row['SupplierName']; ?>"><?php echo $row['SupplierName']; ?></option>
                                <?php } ?>
                            </select>
                        </div>

                        <!-- Product Name -->
                        <div class="form-group">
                            <label for="productName">Product Name</label>
                            <select id="productName" name="productName" class="form-control" required>
                                <?php while($row = mysqli_fetch_array($productQuery)) { ?>
                                    <option value="<?php echo $row['ProductName']; ?>"><?php echo $row['ProductName']; ?></option>
                                <?php } ?>
                            </select>
                        </div>

                        <!-- Quantity -->
                        <div class="form-group">
                            <label for="quantity">Quantity</label>
                            <input type="number" id="quantity" name="quantity" class="form-control" required>
                        </div>

                        <!-- Notes -->
                        <div class="form-group">
                            <label for="notes">Notes</label>
                            <textarea id="notes" name="notes" class="form-control" rows="3" required></textarea>
                        </div>

                        <!-- Admin ID -->
                        <button type="submit" name="submit" class="btn btn-primary">Submit Log Entry</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>

    <?php include_once('includes/footer.php'); ?>
    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
</body>
</html>
