<?php
session_start();
include('includes/dbconnection.php');
if (!isset($_SESSION['vpmsaid'])) {
    header('location:logout.php');
    exit();
}

// Fetch Admin Name
$adminId = $_SESSION['vpmsaid'];
$adminNameQuery = mysqli_query($con, "SELECT AdminName FROM admin WHERE ID='$adminId'");
$adminNameRow = mysqli_fetch_assoc($adminNameQuery);
$adminName = $adminNameRow['AdminName'];

// Fetching other data for the dashboard...
// Total Quantity of All Products
$totalQuantityQuery = mysqli_query($con, "SELECT SUM(Quantity) AS totalQuantity FROM product");
$totalQuantityRow = mysqli_fetch_assoc($totalQuantityQuery);
$totalQuantity = $totalQuantityRow['totalQuantity'];

// Total Number of Products
$totalProductsQuery = mysqli_query($con, "SELECT COUNT(*) AS totalProducts FROM product");
$totalProductsRow = mysqli_fetch_assoc($totalProductsQuery);
$totalProducts = $totalProductsRow['totalProducts'];

// Total Number of Suppliers
$totalSuppliersQuery = mysqli_query($con, "SELECT COUNT(*) AS totalSuppliers FROM supplier");
$totalSuppliersRow = mysqli_fetch_assoc($totalSuppliersQuery);
$totalSuppliers = $totalSuppliersRow['totalSuppliers'];

// Quantity Entered This Month
$currentMonth = date('Y-m');
$quantityEnteredThisMonthQuery = mysqli_query($con, "SELECT SUM(Quantity) AS totalQuantityThisMonth FROM log WHERE Type=1 AND LogDate LIKE '$currentMonth%'");
$quantityEnteredThisMonthRow = mysqli_fetch_assoc($quantityEnteredThisMonthQuery);
$quantityEnteredThisMonth = $quantityEnteredThisMonthRow['totalQuantityThisMonth'] ?? 0;

// Product with the Highest Sales
$highestSalesQuery = mysqli_query($con, "SELECT ProductName, SUM(Quantity) AS totalSales FROM log WHERE Type=0 GROUP BY ProductName ORDER BY totalSales DESC LIMIT 1");
$highestSalesRow = mysqli_fetch_assoc($highestSalesQuery);
$highestSalesProduct = $highestSalesRow['ProductName'];
$highestSalesQuantity = $highestSalesRow['totalSales'];

// Sales Data for Chart
$salesDataQuery = mysqli_query($con, "SELECT LogDate, SUM(Quantity) AS dailySales FROM log WHERE Type=0 GROUP BY LogDate ORDER BY LogDate");
$salesData = [];
while ($row = mysqli_fetch_assoc($salesDataQuery)) {
    $salesData[] = $row;
}
?>

<!doctype html>
<html lang="en">
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <title>Log Entry</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

    <style>
        .stat-box { margin-bottom: 20px; }
    
    </style>
</head>
<body>
    
    <?php include('includes/sidebar.php'); ?>
    <?php include('includes/header.php'); ?>
    
    <div class="breadcrumbs">
        <div class="breadcrumbs-inner">
            <div class="row m-0">
                <div class="col-sm-4">
                    <div class="page-header float-left">
                        <div class="page-title">
                            <strong><h1>Dashboard, Welcome <?php echo $adminName; ?></h1></strong>
                        </div>
                    </div>
                </div>
                <div class="col-sm-8">
                    <div class="page-header float-right">
                        <div class="page-title">
                            <ol class="breadcrumb text-right">
                                <li><a href="dashboard.php">Dashboard</a></li>
                                <li class="active">Sales Entry</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <br>
    <div class="content">
        <div class="animated fadeIn">
            <div class="card">
                <div class="card-header">
                    <strong class="card-title">Record Sale</strong>
                </div>
                <div class="row">
                <!-- Total Quantity -->
                <div class="col-lg-3 col-md-6 stat-box">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Total Quantity of All Products</h5>
                            <p class="card-text"><span class="count"><?php echo $totalQuantity; ?></span></p>
                        </div>
                    </div>
                </div>

                <!-- Total Products -->
                <div class="col-lg-3 col-md-6 stat-box">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Total Products</h5>
                            <p class="card-text"><span class="count"><?php echo $totalProducts; ?></span></p>
                        </div>
                    </div>
                </div>

                <!-- Total Suppliers -->
                <div class="col-lg-3 col-md-6 stat-box">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Total Suppliers</h5>
                            <p class="card-text"><span class="count"><?php echo $totalSuppliers; ?></span></p>
                        </div>
                    </div>
                </div>

                <!-- Quantity Entered This Month -->
                <div class="col-lg-3 col-md-6 stat-box">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Quantity Entered This Month</h5>
                            <p class="card-text"><span class="count"><?php echo $quantityEnteredThisMonth; ?></span></p>
                        </div>
                    </div>
                </div>

                <!-- Highest Sales Product -->
                <div class="col-lg-3 col-md-6 stat-box">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Product with Highest Sales</h5>
                            <p class="card-text"><?php echo $highestSalesProduct; ?> (<?php echo $highestSalesQuantity; ?>)</p>
                        </div>
                    </div>
                </div>

                <!-- Sales Chart -->
                <div class="col-lg-12 stat-box">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Sales Chart</h5>
                            <canvas id="salesChart" style="max-height: 340px; max-width: 100%;"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>
    <div class="content">
        <div class="animated fadeIn">
            <div class="row">
                
            </div>
        </div>
    </div>
    <div class="content">
        <div class="animated fadeIn">
            
        </div>
    </div>
    <div class="clearfix"></div>


    <?php include('includes/footer.php'); ?>

    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
    <script>
        // Sales Chart Data
        const salesData = <?php echo json_encode($salesData); ?>;
        const labels = salesData.map(item => item.LogDate);
        const data = salesData.map(item => item.dailySales);

        // Initialize Chart
        new Chart(document.getElementById('salesChart'), {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Daily Sales',
                    data: data,
                    borderColor: 'rgba(75, 192, 192, 1)',
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    fill: true
                }]
            },
            options: {
                responsive: true,
                scales: {
                    x: { title: { display: true, text: 'Date' } },
                    y: { title: { display: true, text: 'Sales Quantity' } }
                }
            }
        });
        
    </script>
</body>
</html>

