<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Rudys Inventory System</title>
        
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="admin/assets/css/style.css" rel="stylesheet" />
        <style>
            /* Custom styling for Admin button */
            .admin-btn {
                display: inline-block;
                padding: 15px 30px;
                font-size: 1.2em;
                font-weight: bold;
                color: #fff;
                background-color: #28a745;
                border: 2px solid #fff;
                border-radius: 5px;
                text-transform: uppercase;
                text-decoration: none;
                transition: 0.3s;
            }

            .admin-btn:hover {
                background-color: #218838;
                color: #fff;
                box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            }
        </style>
    </head>
    <body id="page-top">
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg bg-secondary text-uppercase fixed-top" id="mainNav">
            <div class="container">
                <a class="navbar-brand" href="index.php"></a>
            </div>
        </nav>
        <!-- Masthead-->
        <header class="masthead bg-primary text-white text-center">
            <div class="container d-flex align-items-center flex-column">
                <!-- Masthead Avatar Image-->
                <img href="index.php" class="masthead-avatar mb-5" src="admin/images/logo.png" alt="..." />

                <!-- Admin Button -->
                <a href="admin/index.php" class="admin-btn">Admin</a>

                <!-- Masthead Heading-->
                <h1 class="masthead-heading text-uppercase mb-0">RUDY'S INVENTORY SYSTEM</h1>
                <!-- Icon Divider-->
                <div class="divider-custom divider-light">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
            </div>
        </header>
    </body>
</html>
